import React from 'react'

export default function NoPage() {
  return (
    <div >
    <p className='text-center mt-60 font-bold text-6xl'>ERROR 404 PAGE NOT FOUND</p>
    </div>
  )
}
